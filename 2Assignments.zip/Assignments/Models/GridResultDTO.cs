﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class GridResultDTO
    {
        public int Id { get; set; }
        public string WebTitle{ get; set; }
        public string WebAddress{ get; set; }
        public string SearchDescription{ get; set; }
    }
}
