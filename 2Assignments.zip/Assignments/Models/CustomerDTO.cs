﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class CustomerDTO
    {
        public int Id { get; set; }
        public String CustomerName { get; set; }
        public String CustomerAddress { get; set; }
        
    }
}
